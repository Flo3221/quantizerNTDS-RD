function [uL,uR] = dummyBC(t,uLex,uRex)
    uL = uLex; 
    uR = uRex;
% end dummyBC